package com.example.iruneexamen2ev;

public interface LibroListener {
    void onLibroSeleccionado(Libro l);
}
