package com.example.iruneexamen2ev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class TiempoActivity extends AppCompatActivity {
    private Spinner spinnerLocalidades;
    private TextView labelLocalidad,hoy,temphoy,deschoy,mañana,tempmañana,descmañana,pasao,temppasao,descpasao;
    private Button volver;
    private final String[] url = new String[] {""};
    private Tiempo tiempohoy,tiempomañana,tiempopasao;
    private ImageView fotohoy,fotomañana,fotopasao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiempo);
        //ids
        labelLocalidad = findViewById(R.id.labelLocalidad);
        spinnerLocalidades = findViewById(R.id.spinnerLocalidades);
        volver = findViewById(R.id.botonVolver);
        hoy = findViewById(R.id.hoy);
        temphoy = findViewById(R.id.temphoy);
        deschoy = findViewById(R.id.deschoy);
        fotohoy = findViewById(R.id.fotoHoy);
        mañana = findViewById(R.id.mañana);
        tempmañana =findViewById(R.id.tempmañana);
        descmañana= findViewById(R.id.descmañana);
        fotomañana = findViewById(R.id.fotomañana);
        pasao = findViewById(R.id.pasao);
        temppasao = findViewById(R.id.temppasao);
        descpasao = findViewById(R.id.descpasao);
        fotopasao = findViewById(R.id.fotopasao);

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        ArrayList<String[]> array = leerFichero();
        cargarSpinner(array);
        spinnerLocalidades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                TextView localidadSeleccionada = (TextView) view;
                labelLocalidad.setText(localidadSeleccionada.getText().toString());
                url[0] = array.get(spinnerLocalidades.getSelectedItemPosition())[1];
                cargarParser();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });





    }
    private void cargarSpinner(ArrayList<String[]> array) {
        ArrayList<String> lista = new ArrayList<>();

        for(int i = 0;i<array.size();i++){
            lista.add(array.get(i)[0]); // la primera posicion es la localidad
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista);
        spinnerLocalidades.setAdapter(arrayAdapter);
    }

    public ArrayList<String[]> leerFichero(){
        String[] partes;
        ArrayList<String[]> array = new ArrayList<String[]>();
        try {
            InputStream fraw = getResources().openRawResource(R.raw.tiempourl);
            BufferedReader brin = new BufferedReader( new InputStreamReader(fraw));
            String linea= brin.readLine();
            partes = linea.split(";");
            array.add(partes);
            while (linea!=null){
                Log.i("Ficheros", linea);
                linea=brin.readLine();
                partes = linea.split(";");
                array.add(partes);
            }
            fraw.close();
        }
        catch (Exception ex) {
            Log.e ("Ficheros", "Error al leer fichero desde recurso raw");
        }

        return array;
    }
    // Metodo que ejecuta la tarea en segundo plano de la carga de datos
    public void cargarParser(){
        CargarXmlTask cargar = new CargarXmlTask();
       cargar.execute(url);
    }

    private class CargarXmlTask extends AsyncTask<String,Integer,Boolean> {

        protected Boolean doInBackground(String... params) {
            ParseadorSAX parseador =
                    new ParseadorSAX(params[0]);
            tiempohoy = parseador.parse("day1");
            tiempomañana = parseador.parse("day2");
            tiempopasao = parseador.parse("day3");
            return true;
        }

        protected void onPostExecute(Boolean result) {

            //hoy
            hoy.setText("HOY: "+tiempohoy.getDia());
            temphoy.setText("Max: "+tiempohoy.getTemperatura_max()+" - Min: "+tiempohoy.getTemperatura_min());
            deschoy.setText(tiempohoy.getDesc());

            // les he tenido que poner una 'a' a las imagenes en el nombre porque su nombre no puede
            // empezar por un numero :(
            String icon = "a" + tiempohoy.getIcono();
            Resources res = getResources();
            int resID = res.getIdentifier(icon, "drawable", getPackageName());
            fotohoy.setImageResource(resID);

            // mañana
            mañana.setText("MAÑANA: "+tiempomañana.getDia());
            tempmañana.setText("Max: "+tiempomañana.getTemperatura_max()+" - Min: "+tiempomañana.getTemperatura_min());
            descmañana.setText(tiempomañana.getDesc());
            icon = "a" + tiempomañana.getIcono();
            resID = res.getIdentifier(icon, "drawable", getPackageName());
            fotomañana.setImageResource(resID);

            // pasao
            pasao.setText("PASADO MAÑANA: "+tiempopasao.getDia());
            temppasao.setText("Max: "+tiempopasao.getTemperatura_max()+" - Min: "+tiempopasao.getTemperatura_min());
            descpasao.setText(tiempopasao.getDesc());
            icon = "a" + tiempopasao.getIcono();
            resID = res.getIdentifier(icon, "drawable", getPackageName());
            fotopasao.setImageResource(resID);
        }
    }
}