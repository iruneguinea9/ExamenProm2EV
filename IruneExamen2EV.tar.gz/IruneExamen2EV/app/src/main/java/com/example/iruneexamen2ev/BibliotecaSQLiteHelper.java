package com.example.iruneexamen2ev;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BibliotecaSQLiteHelper extends SQLiteOpenHelper {

    public BibliotecaSQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creacion de la tabla de libros
        db.execSQL(
                "CREATE TABLE Libro (" +
                        "isbn INTEGER PRIMARY KEY," +
                        "titulo TEXT," +
                        "autor TEXT," +
                        "editorial TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS Libro");
        db.execSQL("CREATE TABLE Libro (" +
                "isbn INTEGER PRIMARY KEY," +
                "titulo TEXT," +
                "autor TEXT," +
                "editorial TEXT)");
    }
}
