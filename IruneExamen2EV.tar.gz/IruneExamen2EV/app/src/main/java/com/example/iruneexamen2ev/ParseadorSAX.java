package com.example.iruneexamen2ev;

import android.sax.Element;
import android.sax.RootElement;
import android.util.Xml;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class ParseadorSAX {

    private final URL rssUrl;
    private Tiempo tiempoActual;

    public ParseadorSAX(String url) {
        try {
            this.rssUrl = new URL (url);
            System.out.println(url);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    // Metodo parse que devuelve un objeto Tiempo
    public Tiempo parse(String dia){
        // Coge el elemento root
        RootElement root = new RootElement("data");

        // Cuando empieza el elemento root, crea el objeto Tiempo
        root.setStartElementListener(attributes -> tiempoActual = new Tiempo());

        // Coge los datos en referencia al dia
        Element day1 = root.getChild(dia);
        day1.getChild("date").setEndTextElementListener(body -> tiempoActual.setDia(body));
        day1.getChild("temperature_max").setEndTextElementListener(body -> tiempoActual.setTemperatura_max(body));
        day1.getChild("temperature_min").setEndTextElementListener(body -> tiempoActual.setTemperatura_min(body));
        day1.getChild("icon").setEndTextElementListener(body -> tiempoActual.setIcono(body));
        day1.getChild("text").setEndTextElementListener(body -> tiempoActual.setDesc(body));


        try {
            Xml.parse(this.getInputStream(),
                    Xml.Encoding.ISO_8859_1,
                    root.getContentHandler());
        }catch (Exception e){
            throw new RuntimeException(e);
        }
        return tiempoActual;
    }

    private InputStream getInputStream() {
        try {
            return rssUrl.openConnection().getInputStream();
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
