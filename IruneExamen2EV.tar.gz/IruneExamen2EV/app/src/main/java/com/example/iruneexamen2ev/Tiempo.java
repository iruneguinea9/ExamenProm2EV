package com.example.iruneexamen2ev;

public class Tiempo {

    private String temperatura_min;
    private String temperatura_max;
    private String dia;
    private String desc;
    private String icono;


    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getTemperatura_max() {
        return temperatura_max;
    }

    public String getTemperatura_min() {
        return temperatura_min;
    }

    public String getDesc() {
        return desc;
    }

    public String getIcono() {
        return icono;
    }

    public void setDesc(String estado) {
        this.desc = estado;
    }

    public void setIcono(String icono) {
        this.icono = icono;
    }

    public void setTemperatura_max(String temperatura_max) {
        this.temperatura_max = temperatura_max;
    }

    public void setTemperatura_min(String temperatura_min) {
        this.temperatura_min = temperatura_min;
    }
}
